module PokemonApiHelper
end
